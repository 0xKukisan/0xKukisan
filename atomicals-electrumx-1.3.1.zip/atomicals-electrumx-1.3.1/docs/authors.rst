.. _Authors:

Authors
=======

* Neil Booth

  Original creator, past maintainer.

* Electrum developers

  Current maintainers.

* Johann Bauer

  Backend DB abstraction.

* John Jegutanis

  Alt-chain integrations.
